
package model;

public class EquiposEntrenamientoAireLibre extends Equipamiento {
    public static final int RESIS_MIN = 1;
    public static final int RESIS_MAX = 10;
    private int resistencia;
    
    
    public EquiposEntrenamientoAireLibre(String nombre, String sector, NivelUso nivelUso, int resistencia) {
        super(nombre, sector, nivelUso);
        this.resistencia = resistencia;
        
    }
//arreglar toString de todas las herencias de equipamiento
    @Override
    public String toString() {
        return super.toString() + " resistencia = " + resistencia;
    }
  
    public void validarResistencia() {
        if (resistencia < RESIS_MIN || resistencia > RESIS_MAX) {
            throw new IllegalArgumentException("La resistencia al clima debe estar entre " + RESIS_MIN + " y " + RESIS_MAX);
        }
    }  
}
