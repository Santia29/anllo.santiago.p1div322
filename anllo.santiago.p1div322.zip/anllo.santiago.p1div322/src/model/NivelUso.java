
package model;

public enum NivelUso {
    BAJA, MEDIA, ALTA
}
