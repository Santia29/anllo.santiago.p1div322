
package model;

import interfaces.Preparable;

public class InstrumentosDeportesEquipo extends Equipamiento implements Preparable {
    
    private String tipoDeDeporte;
    
    public InstrumentosDeportesEquipo(String nombre, String sector, NivelUso nivel, String tipoDeDeporte) {
        super(nombre, sector, nivel);
        this.tipoDeDeporte = tipoDeDeporte;
    }
    
    @Override
    public void prepararParaUsoDiario() {
        System.out.println("Instrumentos de deportes de Equipo preparandose para uso diario");
    }

    @Override
    public String toString() {
        return super.toString() + " tipo de deporte: " + tipoDeDeporte;
    }
}
