
package model;

import exception.ExceptionEquipoDuplicado;
import java.util.ArrayList;
import java.util.List;
import interfaces.Preparable;
        
public class CentroDeEntrenamientoDeportivo {
    
    private String nombre;
    private final List<Equipamiento> equipamiento; 

    public CentroDeEntrenamientoDeportivo(String nombre) {
        this.nombre = nombre;
        equipamiento = new ArrayList<>();
    }
    
    public void agregarEquipos(Equipamiento equipo) throws ExceptionEquipoDuplicado{
        for(Equipamiento e : equipamiento){
            if(e.equals(equipo)){
                throw new ExceptionEquipoDuplicado("Ya existe nombre y/o sector guardado en centro de entrenamiento");
            }
        }
        equipamiento.add(equipo);
    }
    public void mostrarEquipos(){
        System.out.println("Lista de equipos en centro de entrenamiento " + nombre);
        for(Equipamiento e : equipamiento){
            System.out.println(e.toString());
            }   
    }
    
    public void prepararEquipos(){
        for(Equipamiento e: equipamiento){
            if(e instanceof Preparable){
                ((Preparable) e).prepararParaUsoDiario();
            }else{
                System.out.println(e.getNombre() + " No requiere de preparacion");
            }
        }
    }
    
    public void filtrarPorNivelUso(NivelUso nivel){
        System.out.println("Lista de nivel de uso " + nivel + ":");
        for(Equipamiento e : equipamiento){
            if(e.esNivelUso(nivel)){
                System.out.println(e);
            }
        }
    }
    
    public void validarEquipo(Equipamiento e){
        if(e.getNombre() == null || e.getNombre().isEmpty()){
            throw new NullPointerException("nombre no debe estar vacio");
        }
        if (e.getSector() == null || e.getSector().isEmpty()){
            throw new NullPointerException("nombre de sector no debe estar vacio");
        }
        if(e.getNivelUso() == null){
            throw new NullPointerException("nivel de uso debe ser elegida alguna opcion");
        }
        if(e instanceof EquiposEntrenamientoAireLibre){
            ((EquiposEntrenamientoAireLibre) e).validarResistencia();
        }
    }
    
}
