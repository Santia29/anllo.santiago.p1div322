
package model;



public abstract class Equipamiento {
    
    private String nombre;
    private String sector;
    private final NivelUso nivel;

    public Equipamiento(String nombre, String sector, NivelUso nivelUso) {
        this.nombre = nombre;
        this.sector = sector;
        this.nivel = nivelUso;
    }

    public String getNombre() {
        return nombre;
    }

    public String getSector() {
        return sector;  
    }

    public NivelUso getNivelUso() {
        return nivel;
    }
    
    public boolean esNivelUso(NivelUso nivelUso) {
        return this.nivel == nivelUso;
    }
    
    @Override
    public String toString() {
        String claseNombre = getClass().getSimpleName();
        return claseNombre + "|" + " nombre = " + nombre + "|" + " sector = " + sector + "|" + " nivel = " + nivel + "|";
    }
    
    @Override
    public boolean equals(Object o){
        if(this == o) return true;
        if(o == null || getClass() != o.getClass()) return false;
        
        Equipamiento other = (Equipamiento) o;
        return nombre.equals(other.nombre) && sector.equals(other.sector);
    }  
    
    @Override
    public int hashCode(){
        return java.util.Objects.hash(nombre, sector);
    }
}
