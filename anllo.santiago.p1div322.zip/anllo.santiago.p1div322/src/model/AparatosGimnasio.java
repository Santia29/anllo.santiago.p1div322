
package model;

import interfaces.Preparable;


public class AparatosGimnasio extends Equipamiento implements Preparable {
    
    private double pesoMaxSoportado;

    public AparatosGimnasio(String nombre, String sector, NivelUso nivel, double pesoMaxSoportado) {
        super(nombre, sector, nivel);
        this.pesoMaxSoportado = pesoMaxSoportado;
    }

    @Override
    public void prepararParaUsoDiario() {
        System.out.println("Aparatos de gimnasio preparandose para uso diario");
    }

    @Override
    public String toString() {
        return super.toString() + " Peso maximo soportado = " + pesoMaxSoportado;
    }
}
