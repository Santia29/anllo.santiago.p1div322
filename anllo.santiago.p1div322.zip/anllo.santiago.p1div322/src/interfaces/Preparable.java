
package interfaces;

public interface Preparable {
    
    void prepararParaUsoDiario();
    
}
