
package exception;

public class ExceptionEquipoDuplicado extends RuntimeException{
    
    public ExceptionEquipoDuplicado(String mensaje){
        super(mensaje);
        
    }
    
    
}
