package anllo.santiago.p1div322;

import model.AparatosGimnasio;
import model.CentroDeEntrenamientoDeportivo;
import model.Equipamiento;
import model.NivelUso;
import exception.ExceptionEquipoDuplicado;
import model.EquiposEntrenamientoAireLibre;
import model.InstrumentosDeportesEquipo;

public class AnlloSantiagoP1div322 {


    public static void main(String[] args) {
        
        CentroDeEntrenamientoDeportivo centroEntreno = new CentroDeEntrenamientoDeportivo("Gatica");
        Equipamiento e1 = new AparatosGimnasio("rejunte","gimnasio",NivelUso.ALTA, 2000.0);
        Equipamiento e2 = new AparatosGimnasio("rejunte","gimnasio",NivelUso.ALTA, 2000.0);
        Equipamiento e3 = new EquiposEntrenamientoAireLibre("vermelho", "pesas", NivelUso.MEDIA, 5);   
        Equipamiento e4 = new InstrumentosDeportesEquipo("tripon", "cardio", NivelUso.BAJA, "Natacion");
        
        centroEntreno.validarEquipo(e1);
        centroEntreno.validarEquipo(e2);
        centroEntreno.validarEquipo(e3);
        centroEntreno.validarEquipo(e4);
        
        centroEntreno.agregarEquipos(e1);
        try{
            centroEntreno.agregarEquipos(e2);
        }catch(ExceptionEquipoDuplicado e){
            System.out.println("Error: " + e.getMessage());
        }
        
        centroEntreno.agregarEquipos(e3);
        centroEntreno.agregarEquipos(e4);
        centroEntreno.prepararEquipos();
        centroEntreno.mostrarEquipos();
        centroEntreno.filtrarPorNivelUso(NivelUso.ALTA);
    } 
}
 